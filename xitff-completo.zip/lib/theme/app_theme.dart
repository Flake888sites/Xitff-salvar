import 'package:flutter/material.dart';

/// Cores e estilos centralizados do Red Xiter.
/// Mantém a identidade visual vermelho/preto do app original.
class AppTheme {
  static const Color red = Color(0xFFFF0000);
  static const Color redDark = Color(0xFFCC0000);
  static const Color redLoginBg = Color(0xFFE8000E);
  static const Color black = Color(0xFF000000);
  static const Color gray = Color(0xFF333333);
  static const Color warningBg = Color(0xFF220000);
  static const Color warningText = Color(0xFFFF6666);

  static ThemeData get theme {
    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: black,
      colorScheme: const ColorScheme.dark(
        primary: red,
        secondary: red,
        surface: black,
      ),
      fontFamily: 'Roboto',
    );
  }
}
