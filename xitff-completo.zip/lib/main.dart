import 'package:flutter/material.dart';
import 'theme/app_theme.dart';
import 'services/session_service.dart';
import 'screens/login_screen.dart';
import 'screens/menu_screen.dart';

void main() {
  runApp(const XitFFApp());
}

class XitFFApp extends StatelessWidget {
  const XitFFApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'iFood',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.theme,
      home: const _EntryDecider(),
    );
  }
}

/// Decide, ao abrir o app, se mostra o Login ou vai direto pro Menu
/// (equivalente à lógica que tínhamos no onCreate do MainActivity.kt).
class _EntryDecider extends StatelessWidget {
  const _EntryDecider();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<bool>(
      future: SessionService.deveEntrarDireto(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Scaffold(
            backgroundColor: AppTheme.black,
            body: Center(
              child: CircularProgressIndicator(color: AppTheme.red),
            ),
          );
        }
        return snapshot.data! ? const MenuScreen() : const LoginScreen();
      },
    );
  }
}
