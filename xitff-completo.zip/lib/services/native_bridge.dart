import 'package:flutter/services.dart';

/// Ponte (platform channel) entre o Dart e o código nativo Kotlin.
/// Cobre duas coisas que o Flutter puro não consegue fazer sozinho:
///  1. Desenhar um overlay flutuante sobre outros apps
///  2. Chamar APIs privilegiadas do sistema via Shizuku
class NativeBridge {
  static const _overlayChannel = MethodChannel('xitff/overlay');
  static const _shizukuChannel = MethodChannel('xitff/shizuku');

  // ── Overlay ──────────────────────────────────────────────

  /// Verifica se o app já tem permissão de overlay (SYSTEM_ALERT_WINDOW).
  static Future<bool> temPermissaoOverlay() async {
    try {
      return await _overlayChannel.invokeMethod<bool>('temPermissao') ?? false;
    } on PlatformException {
      return false;
    }
  }

  /// Abre a tela de sistema para o usuário conceder a permissão de overlay.
  static Future<void> pedirPermissaoOverlay() async {
    try {
      await _overlayChannel.invokeMethod('pedirPermissao');
    } on PlatformException {
      // Ignora — o usuário pode cancelar a tela de permissão.
    }
  }

  /// Inicia o serviço de HUD flutuante nativo.
  static Future<void> iniciarHud() async {
    try {
      await _overlayChannel.invokeMethod('iniciarHud');
    } on PlatformException {
      // Falha ao iniciar o serviço — tratado na tela chamadora.
    }
  }

  /// Encerra o serviço de HUD flutuante nativo.
  static Future<void> pararHud() async {
    try {
      await _overlayChannel.invokeMethod('pararHud');
    } on PlatformException {
      // Ignora.
    }
  }

  // ── Shizuku ──────────────────────────────────────────────

  /// Verifica se o Shizuku está ativo e com permissão concedida.
  static Future<bool> shizukuAtivo() async {
    try {
      return await _shizukuChannel.invokeMethod<bool>('estaAtivo') ?? false;
    } on PlatformException {
      return false;
    }
  }

  /// Abre o app Shizuku Manager, se instalado.
  static Future<void> abrirShizuku() async {
    try {
      await _shizukuChannel.invokeMethod('abrirApp');
    } on PlatformException {
      // Ignora — tratado na UI com mensagem própria.
    }
  }

  /// Solicita a permissão do Shizuku ao usuário.
  static Future<void> pedirPermissaoShizuku() async {
    try {
      await _shizukuChannel.invokeMethod('pedirPermissao');
    } on PlatformException {
      // Ignora.
    }
  }

  /// Define o DPI da tela (0 = display principal).
  static Future<String?> setDensity(int dpi) async {
    try {
      await _shizukuChannel.invokeMethod('setDensity', {'dpi': dpi});
      return null; // sucesso
    } on PlatformException catch (e) {
      return e.message ?? 'Erro desconhecido';
    }
  }

  /// Restaura o DPI padrão da tela.
  static Future<String?> resetDensity() async {
    try {
      await _shizukuChannel.invokeMethod('resetDensity');
      return null;
    } on PlatformException catch (e) {
      return e.message ?? 'Erro desconhecido';
    }
  }

  /// Define a resolução da tela.
  static Future<String?> setSize(int width, int height) async {
    try {
      await _shizukuChannel.invokeMethod('setSize', {'width': width, 'height': height});
      return null;
    } on PlatformException catch (e) {
      return e.message ?? 'Erro desconhecido';
    }
  }

  /// Restaura a resolução padrão da tela.
  static Future<String?> resetSize() async {
    try {
      await _shizukuChannel.invokeMethod('resetSize');
      return null;
    } on PlatformException catch (e) {
      return e.message ?? 'Erro desconhecido';
    }
  }

  /// Define uma configuração do tipo "global" (settings put global).
  static Future<String?> putGlobalSetting(String key, String value) async {
    try {
      await _shizukuChannel.invokeMethod('putGlobalSetting', {'key': key, 'value': value});
      return null;
    } on PlatformException catch (e) {
      return e.message ?? 'Erro desconhecido';
    }
  }

  /// Define uma configuração do tipo "system" (settings put system).
  static Future<String?> putSystemSetting(String key, String value) async {
    try {
      await _shizukuChannel.invokeMethod('putSystemSetting', {'key': key, 'value': value});
      return null;
    } on PlatformException catch (e) {
      return e.message ?? 'Erro desconhecido';
    }
  }
}
