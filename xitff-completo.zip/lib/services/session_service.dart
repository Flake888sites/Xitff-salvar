import 'package:flutter/services.dart' show rootBundle;
import 'package:shared_preferences/shared_preferences.dart';

/// Gerencia login, senha e persistência de sessão.
/// Equivalente ao antigo LoginActivity.kt + SharedPreferences do Kotlin.
class SessionService {
  static const _keyManterLogin = 'manter_login';
  static const _keyUsuarioLogado = 'usuario_logado';

  /// Lê o arquivo assets/passwords.txt e retorna a lista de senhas válidas.
  /// Linhas vazias ou começando com # são ignoradas.
  static Future<List<String>> _carregarSenhasValidas() async {
    final conteudo = await rootBundle.loadString('assets/passwords.txt');
    return conteudo
        .split('\n')
        .map((l) => l.trim())
        .where((l) => l.isNotEmpty && !l.startsWith('#'))
        .toList();
  }

  /// Verifica se a senha informada está na lista de senhas válidas.
  static Future<bool> verificarSenha(String senha) async {
    final validas = await _carregarSenhasValidas();
    return validas.contains(senha);
  }

  /// Salva o usuário logado na sessão.
  static Future<void> salvarLogin(String usuario) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyUsuarioLogado, usuario);
  }

  /// Retorna o usuário logado, ou null se não houver.
  static Future<String?> getUsuarioLogado() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyUsuarioLogado);
  }

  /// Liga/desliga a opção "manter login".
  static Future<void> setManterLogin(bool valor) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyManterLogin, valor);
  }

  /// Verifica se "manter login" está ativo.
  static Future<bool> getManterLogin() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_keyManterLogin) ?? false;
  }

  /// Decide se o app deve pular a tela de login ao abrir.
  static Future<bool> deveEntrarDireto() async {
    final manterLogin = await getManterLogin();
    if (manterLogin) return true;
    final usuario = await getUsuarioLogado();
    return usuario != null;
  }

  /// Faz logout completo (limpa usuário e manter login).
  static Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_keyUsuarioLogado);
    await prefs.setBool(_keyManterLogin, false);
  }
}
