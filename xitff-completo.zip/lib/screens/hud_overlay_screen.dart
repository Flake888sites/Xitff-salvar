import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/native_bridge.dart';

class HudOverlayScreen extends StatefulWidget {
  const HudOverlayScreen({super.key});

  @override
  State<HudOverlayScreen> createState() => _HudOverlayScreenState();
}

class _HudOverlayScreenState extends State<HudOverlayScreen> {
  bool _shizukuAtivo = false;
  bool _estabilizar = false;
  bool _estavel2x = false;
  bool _performance = false;
  bool _touchBoost = false;
  bool _wifiLock = false;
  double _dpiSlider = 2; // 0..4, índice central = padrão

  final _dpiLabels = ['Baixo (-2)', 'Menor (-1)', 'Padrão', 'Maior (+1)', 'Alto (+2)'];
  final _dpiOffsets = [-100, -50, 0, 50, 100];
  int _dpiOriginal = 420; // valor de referência, ajustável

  @override
  void initState() {
    super.initState();
    _verificarShizuku();
    _iniciarOverlayNativo();
  }

  Future<void> _verificarShizuku() async {
    final ativo = await NativeBridge.shizukuAtivo();
    if (!mounted) return;
    setState(() => _shizukuAtivo = ativo);
    if (!ativo) _mostrarAvisoShizuku();
  }

  Future<void> _iniciarOverlayNativo() async {
    final temPermissao = await NativeBridge.temPermissaoOverlay();
    if (!temPermissao) {
      await NativeBridge.pedirPermissaoOverlay();
      return;
    }
    await NativeBridge.iniciarHud();
  }

  void _mostrarAvisoShizuku() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: const Text('Shizuku inativo', style: TextStyle(color: Colors.white)),
        content: const Text(
          'O Shizuku não está em execução, ative-o para liberar algumas funções.',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar', style: TextStyle(color: Colors.grey)),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              NativeBridge.abrirShizuku();
            },
            child: const Text('Abrir Shizuku', style: TextStyle(color: AppTheme.red)),
          ),
        ],
      ),
    );
  }

  void _mostrarMensagem(String texto, {bool erro = false}) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(texto, textAlign: TextAlign.center),
        backgroundColor: erro ? const Color(0xE6660000) : const Color(0xE6323232),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        margin: const EdgeInsets.only(bottom: 40, left: 40, right: 40),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Future<bool> _checarShizukuOuAvisar() async {
    final ativo = await NativeBridge.shizukuAtivo();
    if (!ativo) {
      _mostrarMensagem('Shizuku não está ativo!', erro: true);
      setState(() => _shizukuAtivo = false);
      return false;
    }
    return true;
  }

  @override
  void dispose() {
    NativeBridge.pararHud();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.black,
      appBar: AppBar(
        backgroundColor: const Color(0xFF111111),
        title: Row(
          children: [
            const Text('RED XITER', style: TextStyle(color: AppTheme.red, fontSize: 14, letterSpacing: 1)),
            const Spacer(),
            Text(
              _shizukuAtivo ? '⚡ON' : '⚡OFF',
              style: TextStyle(
                color: _shizukuAtivo ? const Color(0xFF00FF00) : const Color(0xFFFF4444),
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(14),
        child: ListView(
          children: [
            const Text('CONTROLES', style: TextStyle(color: AppTheme.red, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1)),
            const SizedBox(height: 6),
            _switchTile('Estabilizar', _estabilizar, (v) {
              setState(() => _estabilizar = v);
              _mostrarMensagem(v ? 'Estabilizar ativado' : 'Estabilizar desativado');
            }),
            _switchTile('2x Estável', _estavel2x, (v) {
              setState(() => _estavel2x = v);
              _mostrarMensagem(v ? '2x Estável ativado' : '2x Estável desativado');
            }),
            const Divider(color: Color(0xFF330000), height: 30),
            const Text('OTIMIZAÇÕES (SHIZUKU)', style: TextStyle(color: AppTheme.red, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1)),
            const SizedBox(height: 6),
            _switchTile('⚡ Modo Performance', _performance, (v) async {
              if (!await _checarShizukuOuAvisar()) return;
              final escala = v ? '0.5' : '1.0';
              await NativeBridge.putGlobalSetting('animator_duration_scale', escala);
              await NativeBridge.putGlobalSetting('transition_animation_scale', escala);
              await NativeBridge.putGlobalSetting('window_animation_scale', escala);
              setState(() => _performance = v);
              _mostrarMensagem(v ? '⚡ Performance ON' : 'Performance normal');
            }),
            _switchTile('👆 Touch Boost', _touchBoost, (v) async {
              if (!await _checarShizukuOuAvisar()) return;
              await NativeBridge.putSystemSetting('pointer_speed', v ? '5' : '0');
              setState(() => _touchBoost = v);
              _mostrarMensagem(v ? '👆 Touch Boost ON' : 'Touch normal');
            }),
            _switchTile('📶 WiFi Alta Performance', _wifiLock, (v) async {
              if (!await _checarShizukuOuAvisar()) return;
              await NativeBridge.putGlobalSetting('wifi_sleep_policy', v ? '2' : '0');
              setState(() => _wifiLock = v);
              _mostrarMensagem(v ? '📶 WiFi em alta performance' : 'WiFi modo normal');
            }),
            const SizedBox(height: 10),
            Text('🎯 DPI: ${_dpiLabels[_dpiSlider.toInt()]}', style: const TextStyle(color: Colors.white, fontSize: 12)),
            SliderTheme(
              data: SliderTheme.of(context).copyWith(
                activeTrackColor: AppTheme.red,
                inactiveTrackColor: const Color(0xFF333333),
                thumbColor: AppTheme.red,
              ),
              child: Slider(
                value: _dpiSlider,
                min: 0,
                max: 4,
                divisions: 4,
                onChanged: (v) => setState(() => _dpiSlider = v),
                onChangeEnd: (v) async {
                  if (!await _checarShizukuOuAvisar()) return;
                  final novoDpi = _dpiOriginal + _dpiOffsets[v.toInt()];
                  final erro = await NativeBridge.setDensity(novoDpi);
                  if (erro != null) {
                    _mostrarMensagem('Erro DPI: $erro', erro: true);
                  } else {
                    _mostrarMensagem('DPI: $novoDpi');
                  }
                },
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: () async {
                  if (!await _checarShizukuOuAvisar()) return;
                  await NativeBridge.resetDensity();
                  await NativeBridge.putGlobalSetting('animator_duration_scale', '1.0');
                  await NativeBridge.putGlobalSetting('transition_animation_scale', '1.0');
                  await NativeBridge.putGlobalSetting('window_animation_scale', '1.0');
                  await NativeBridge.putSystemSetting('pointer_speed', '0');
                  await NativeBridge.putGlobalSetting('wifi_sleep_policy', '0');
                  setState(() {
                    _performance = false;
                    _touchBoost = false;
                    _wifiLock = false;
                    _dpiSlider = 2;
                  });
                  _mostrarMensagem('✓ Tudo restaurado ao padrão');
                },
                style: OutlinedButton.styleFrom(
                  foregroundColor: const Color(0xFFAAAAAA),
                  side: const BorderSide(color: Color(0xFF444444)),
                ),
                child: const Text('↺ Restaurar Padrões'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _switchTile(String label, bool valor, void Function(bool) onChanged) {
    return Container(
      margin: const EdgeInsets.only(bottom: 4),
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: const Color(0x1AFFFFFF),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: Color(0xFFDDDDDD), fontSize: 13)),
          Switch(value: valor, activeThumbColor: AppTheme.red, onChanged: onChanged),
        ],
      ),
    );
  }
}
