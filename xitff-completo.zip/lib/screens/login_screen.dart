import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/session_service.dart';
import 'menu_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _usuarioCtrl = TextEditingController();
  final _senhaCtrl = TextEditingController();

  @override
  void dispose() {
    _usuarioCtrl.dispose();
    _senhaCtrl.dispose();
    super.dispose();
  }

  void _mostrarMensagem(String texto) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(texto, textAlign: TextAlign.center),
        backgroundColor: const Color(0xE6323232),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        margin: const EdgeInsets.only(bottom: 40, left: 60, right: 60),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Future<void> _tentarLogin() async {
    final usuario = _usuarioCtrl.text.trim();
    final senha = _senhaCtrl.text.trim();

    if (usuario.isEmpty) {
      _mostrarMensagem('Digite seu usuário');
      return;
    }
    if (senha.isEmpty) {
      _mostrarMensagem('Digite sua senha');
      return;
    }

    final valida = await SessionService.verificarSenha(senha);
    if (!valida) {
      _mostrarMensagem('Senha incorreta!');
      return;
    }

    await SessionService.salvarLogin(usuario);
    _mostrarMensagem('Divirta-se com o Xit, $usuario');

    await Future.delayed(const Duration(milliseconds: 700));
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const MenuScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.redLoginBg,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 8),
              const Icon(Icons.chevron_left, color: Colors.white, size: 32),
              const SizedBox(height: 4),
              const Center(
                child: Padding(
                  padding: EdgeInsets.only(bottom: 60),
                  child: Text(
                    'Login',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              const Text(
                'Usuário',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
              ),
              const SizedBox(height: 6),
              _buildInputBox(
                controller: _usuarioCtrl,
                hint: 'Digite seu usuário',
                icon: Icons.email_outlined,
                obscure: false,
              ),
              const SizedBox(height: 20),
              const Text(
                'Senha',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
              ),
              const SizedBox(height: 6),
              _buildInputBox(
                controller: _senhaCtrl,
                hint: 'Digite sua senha',
                icon: Icons.lock_outline,
                obscure: true,
                onSubmit: (_) => _tentarLogin(),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  onPressed: _tentarLogin,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: AppTheme.redLoginBg,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                  ),
                  child: const Text(
                    'Entrar',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: const [
                  Text('Criar conta', style: TextStyle(color: Colors.white, fontSize: 14)),
                  Text('Recuperar conta', style: TextStyle(color: Colors.white, fontSize: 14)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInputBox({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    required bool obscure,
    void Function(String)? onSubmit,
  }) {
    return Container(
      height: 56,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(4),
      ),
      child: Row(
        children: [
          const SizedBox(width: 14),
          Icon(icon, color: const Color(0xFFBBBBBB), size: 20),
          Expanded(
            child: TextField(
              controller: controller,
              obscureText: obscure,
              onSubmitted: onSubmit,
              style: const TextStyle(color: Color(0xFF111111), fontSize: 15),
              decoration: InputDecoration(
                hintText: hint,
                hintStyle: const TextStyle(color: Color(0xFFAAAAAA)),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(horizontal: 8),
              ),
            ),
          ),
          const SizedBox(width: 14),
        ],
      ),
    );
  }
}
