import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/session_service.dart';
import 'hud_overlay_screen.dart';

class MenuScreen extends StatefulWidget {
  const MenuScreen({super.key});

  @override
  State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  int _abaAtual = 0; // 0 = Início, 1 = Flutuante

  bool _manterLogin = false;
  bool _auxilioMira = false;

  double _geral = 0, _redDot = 0, _mira2x = 0, _mira4x = 0;

  @override
  void initState() {
    super.initState();
    _carregarManterLogin();
  }

  Future<void> _carregarManterLogin() async {
    final valor = await SessionService.getManterLogin();
    if (mounted) setState(() => _manterLogin = valor);
  }

  void _mostrarMensagem(String texto) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(texto, textAlign: TextAlign.center),
        backgroundColor: const Color(0xE6323232),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        margin: const EdgeInsets.only(bottom: 40, left: 60, right: 60),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _aplicarTemplate(double g, double rd, double m2, double m4) {
    setState(() {
      _geral = g;
      _redDot = rd;
      _mira2x = m2;
      _mira4x = m4;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.black,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Center(
                child: Padding(
                  padding: EdgeInsets.only(bottom: 20),
                  child: Text(
                    'RED XITER',
                    style: TextStyle(
                      color: AppTheme.red,
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                    ),
                  ),
                ),
              ),
              _buildTabs(),
              const SizedBox(height: 20),
              if (_abaAtual == 0) _buildAbaInicio() else _buildAbaFlutuante(),
              const Divider(color: Color(0xFF222222), height: 46),
              _buildManterLogin(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTabs() {
    return Row(
      children: [
        Expanded(child: _tabButton('INÍCIO', 0)),
        const SizedBox(width: 10),
        Expanded(child: _tabButton('FLUTUANTE', 1)),
      ],
    );
  }

  Widget _tabButton(String texto, int index) {
    final ativo = _abaAtual == index;
    return ElevatedButton(
      onPressed: () => setState(() => _abaAtual = index),
      style: ElevatedButton.styleFrom(
        backgroundColor: ativo ? AppTheme.redDark : AppTheme.gray,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
      ),
      child: Text(texto, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
    );
  }

  Widget _buildAbaInicio() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _switchRow('Auxílio de Mira', _auxilioMira, (v) {
          setState(() => _auxilioMira = v);
          _mostrarMensagem(v ? 'Auxílio de Mira ativado' : 'Auxílio de Mira desativado');
        }),
        const SizedBox(height: 10),
        _sensiSlider('Geral', _geral, (v) => setState(() => _geral = v)),
        _sensiSlider('Red Dot', _redDot, (v) => setState(() => _redDot = v)),
        _sensiSlider('Mira 2x', _mira2x, (v) => setState(() => _mira2x = v)),
        _sensiSlider('Mira 4x', _mira4x, (v) => setState(() => _mira4x = v)),
        const SizedBox(height: 20),
        _buildTemplateGrid(),
        const Divider(color: Color(0xFF222222), height: 46),
        const Text(
          'Funções avançadas',
          style: TextStyle(color: AppTheme.red, fontSize: 15, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 4),
        _buildAvisoAvancado(),
        const SizedBox(height: 16),
        SizedBox(
          width: double.infinity,
          height: 60,
          child: ElevatedButton(
            onPressed: () => _mostrarMensagem('Abrindo o jogo...'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.red,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
            ),
            child: const Text(
              'INICIAR GAME',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 0.5),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildAbaFlutuante() {
    return Column(
      children: [
        const SizedBox(height: 10),
        const Text('MODO OVERLAY', style: TextStyle(color: Colors.white, letterSpacing: 1)),
        const SizedBox(height: 30),
        Center(
          child: GestureDetector(
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const HudOverlayScreen()),
              );
            },
            child: Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const RadialGradient(
                  colors: [AppTheme.red, Color(0xFF880000)],
                ),
                border: Border.all(color: Colors.white, width: 2),
              ),
              child: const Center(
                child: Text(
                  'ATIVAR\nHUD',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 15),
        const Text('Abre o painel de controles', style: TextStyle(color: Color(0xFF555555))),
      ],
    );
  }

  Widget _buildTemplateGrid() {
    final templates = [
      {'nome': 'DESERT', 'g': 190.0, 'rd': 150.0, 'm2': 140.0, 'm4': 120.0},
      {'nome': 'UMP', 'g': 200.0, 'rd': 185.0, 'm2': 170.0, 'm4': 165.0},
      {'nome': 'SHOTGUN', 'g': 100.0, 'rd': 90.0, 'm2': 80.0, 'm4': 70.0},
      {'nome': 'FREE', 'g': 165.0, 'rd': 130.0, 'm2': 115.0, 'm4': 100.0},
    ];
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 8,
      crossAxisSpacing: 8,
      childAspectRatio: 2.6,
      children: templates.map((t) {
        return ElevatedButton(
          onPressed: () {
            _aplicarTemplate(t['g'] as double, t['rd'] as double, t['m2'] as double, t['m4'] as double);
            _mostrarMensagem('Template ${t['nome']} aplicado');
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF440000),
            foregroundColor: Colors.white,
            side: const BorderSide(color: Color(0xFF660000)),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
          ),
          child: Text(t['nome'] as String, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
        );
      }).toList(),
    );
  }

  Widget _buildAvisoAvancado() {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppTheme.warningBg,
        borderRadius: BorderRadius.circular(4),
      ),
      child: const Row(
        children: [
          Icon(Icons.warning_amber_rounded, color: Color(0xFFFF4444), size: 18),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              'Cuidado! Risco de inutilização do celular. Use apenas se souber o que está fazendo.',
              style: TextStyle(color: AppTheme.warningText, fontSize: 11),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildManterLogin() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Manter login', style: TextStyle(color: Color(0xFF888888), fontSize: 13)),
            Switch(
              value: _manterLogin,
              activeThumbColor: AppTheme.red,
              onChanged: (v) async {
                setState(() => _manterLogin = v);
                await SessionService.setManterLogin(v);
                _mostrarMensagem(v ? 'Login automático ativado' : 'Login automático desativado');
              },
            ),
          ],
        ),
        const Text(
          'Quando ativo, o app abre direto sem pedir login',
          style: TextStyle(color: Color(0xFF555555), fontSize: 11),
        ),
      ],
    );
  }

  Widget _switchRow(String label, bool valor, void Function(bool) onChanged) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: const TextStyle(color: Colors.white, fontSize: 14)),
        Switch(value: valor, activeThumbColor: AppTheme.red, onChanged: onChanged),
      ],
    );
  }

  Widget _sensiSlider(String label, double valor, void Function(double) onChanged) {
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(color: AppTheme.red, fontSize: 13, fontWeight: FontWeight.w600)),
          Row(
            children: [
              Expanded(
                child: SliderTheme(
                  data: SliderTheme.of(context).copyWith(
                    activeTrackColor: AppTheme.red,
                    inactiveTrackColor: const Color(0xFF333333),
                    thumbColor: AppTheme.red,
                    trackHeight: 4,
                  ),
                  child: Slider(
                    value: valor,
                    min: 0,
                    max: 200,
                    onChanged: onChanged,
                  ),
                ),
              ),
              SizedBox(
                width: 32,
                child: Text(
                  valor.toInt().toString(),
                  textAlign: TextAlign.right,
                  style: const TextStyle(color: Colors.white, fontSize: 13),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
