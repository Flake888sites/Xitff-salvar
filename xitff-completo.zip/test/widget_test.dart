// Teste básico: verifica se o app inicializa sem erros.

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:xitff/main.dart';

void main() {
  testWidgets('App inicializa sem erros', (WidgetTester tester) async {
    await tester.pumpWidget(const XitFFApp());
    await tester.pump();
    expect(find.byType(MaterialApp), findsOneWidget);
  });
}
