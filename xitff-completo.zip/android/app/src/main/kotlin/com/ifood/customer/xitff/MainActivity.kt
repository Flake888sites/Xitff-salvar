package com.ifood.customer.xitff

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import rikka.shizuku.Shizuku

class MainActivity : FlutterActivity() {

    private val OVERLAY_CHANNEL = "xitff/overlay"
    private val SHIZUKU_CHANNEL = "xitff/shizuku"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        // ── Canal de Overlay (HUD flutuante) ──
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, OVERLAY_CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "temPermissao" -> result.success(Settings.canDrawOverlays(this))

                    "pedirPermissao" -> {
                        startActivity(
                            Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:$packageName")
                            )
                        )
                        result.success(null)
                    }

                    "iniciarHud" -> {
                        startService(Intent(this, FloatingService::class.java))
                        result.success(null)
                    }

                    "pararHud" -> {
                        stopService(Intent(this, FloatingService::class.java))
                        result.success(null)
                    }

                    else -> result.notImplemented()
                }
            }

        // ── Canal do Shizuku ──
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, SHIZUKU_CHANNEL)
            .setMethodCallHandler { call, result ->
                try {
                    when (call.method) {
                        "estaAtivo" -> {
                            val ativo = try {
                                Shizuku.pingBinder() &&
                                    Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
                            } catch (e: Exception) {
                                false
                            }
                            result.success(ativo)
                        }

                        "pedirPermissao" -> {
                            try {
                                Shizuku.requestPermission(1001)
                            } catch (_: Exception) {}
                            result.success(null)
                        }

                        "abrirApp" -> {
                            val intent = packageManager.getLaunchIntentForPackage("mew.shizuku.manager")
                            if (intent != null) {
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                startActivity(intent)
                            }
                            result.success(null)
                        }

                        "setDensity" -> {
                            val dpi = call.argument<Int>("dpi") ?: throw Exception("dpi ausente")
                            ShizukuUtils.setDensity(dpi)
                            result.success(null)
                        }

                        "resetDensity" -> {
                            ShizukuUtils.resetDensity()
                            result.success(null)
                        }

                        "setSize" -> {
                            val width = call.argument<Int>("width") ?: throw Exception("width ausente")
                            val height = call.argument<Int>("height") ?: throw Exception("height ausente")
                            ShizukuUtils.setSize(width, height)
                            result.success(null)
                        }

                        "resetSize" -> {
                            ShizukuUtils.resetSize()
                            result.success(null)
                        }

                        "putGlobalSetting" -> {
                            val key = call.argument<String>("key") ?: throw Exception("key ausente")
                            val value = call.argument<String>("value") ?: throw Exception("value ausente")
                            ShizukuUtils.putGlobalSetting(key, value)
                            result.success(null)
                        }

                        "putSystemSetting" -> {
                            val key = call.argument<String>("key") ?: throw Exception("key ausente")
                            val value = call.argument<String>("value") ?: throw Exception("value ausente")
                            ShizukuUtils.putSystemSetting(key, value)
                            result.success(null)
                        }

                        else -> result.notImplemented()
                    }
                } catch (e: Exception) {
                    result.error("SHIZUKU_ERROR", e.message, null)
                }
            }
    }
}
