package com.ifood.customer.xitff

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView

/**
 * Serviço mínimo de overlay: desenha uma bolinha flutuante arrastável
 * sobre outros apps (ex: durante o jogo). Ao tocar, volta o foco pro
 * app principal (Flutter), onde ficam todos os controles reais.
 */
class FloatingService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var bubbleView: TextView
    private lateinit var bubbleParams: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val overlayType = if (android.os.Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        bubbleParams = WindowManager.LayoutParams(
            dpToPx(52), dpToPx(52),
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 50; y = 100
        }

        bubbleView = TextView(this).apply {
            text = "🎯"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = android.view.Gravity.CENTER
            setBackgroundColor(0xCCFF0000.toInt())
        }

        configurarArraste()

        try {
            wm.addView(bubbleView, bubbleParams)
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun configurarArraste() {
        var dragging = false
        var initX = 0; var initY = 0
        var touchX = 0f; var touchY = 0f

        bubbleView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    dragging = false
                    initX = bubbleParams.x; initY = bubbleParams.y
                    touchX = event.rawX; touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (Math.abs(dx) > 8 || Math.abs(dy) > 8) dragging = true
                    bubbleParams.x = initX + dx
                    bubbleParams.y = initY + dy
                    wm.updateViewLayout(bubbleView, bubbleParams)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragging) {
                        // Toque simples: traz o app Flutter de volta ao primeiro plano
                        val intent = packageManager.getLaunchIntentForPackage(packageName)
                        intent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                        startActivity(intent)
                    }
                    true
                }
                else -> false
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { wm.removeView(bubbleView) } catch (_: Exception) {}
    }

    private fun dpToPx(dp: Int) = (dp * resources.displayMetrics.density + 0.5f).toInt()
}
