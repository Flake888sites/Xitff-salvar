package com.ifood.customer.xitff

import android.os.IBinder
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper

object ShizukuUtils {

    private fun getWindowManager(): Any {
        val binder  = SystemServiceHelper.getSystemService("window")
        val wrapped = ShizukuBinderWrapper(binder)
        val stub    = Class.forName("android.view.IWindowManager\$Stub")
        return stub.getMethod("asInterface", IBinder::class.java).invoke(null, wrapped)!!
    }

    fun setDensity(dpi: Int) {
        val wm = getWindowManager()
        // Assinatura confirmada em testes reais: setForcedDisplayDensity(int displayId, int density)
        wm.javaClass.getMethod("setForcedDisplayDensity", Int::class.java, Int::class.java)
            .invoke(wm, 0, dpi)
    }

    fun resetDensity() {
        val wm = getWindowManager()
        wm.javaClass.getMethod("clearForcedDisplayDensity", Int::class.java)
            .invoke(wm, 0)
    }

    fun setSize(width: Int, height: Int) {
        val wm = getWindowManager()
        try {
            wm.javaClass.getMethod("setForcedDisplaySize", Int::class.java, Int::class.java, Int::class.java)
                .invoke(wm, 0, width, height)
        } catch (_: Exception) {
            wm.javaClass.getMethod("setForcedDisplaySize", Int::class.java, Int::class.java)
                .invoke(wm, width, height)
        }
    }

    fun resetSize() {
        val wm = getWindowManager()
        try {
            wm.javaClass.getMethod("clearForcedDisplaySize", Int::class.java).invoke(wm, 0)
        } catch (_: Exception) {
            wm.javaClass.getMethod("clearForcedDisplaySize").invoke(wm)
        }
    }

    fun putGlobalSetting(key: String, value: String) = putSetting("global", key, value)
    fun putSystemSetting(key: String, value: String)  = putSetting("system", key, value)

    private fun putSetting(table: String, key: String, value: String) {
        val binder   = SystemServiceHelper.getSystemService("settings")
        val wrapped  = ShizukuBinderWrapper(binder)
        val stub     = Class.forName("android.content.IContentProvider\$Stub")
        val provider = stub.getMethod("asInterface", IBinder::class.java).invoke(null, wrapped)!!
        val bundle   = android.os.Bundle().apply { putString("value", value) }
        val methods  = provider.javaClass.methods.filter { it.name == "call" }.sortedBy { it.parameterCount }
        for (m in methods) {
            try {
                when (m.parameterCount) {
                    4 -> { m.invoke(provider, table, "PUT", key, bundle); return }
                    5 -> { m.invoke(provider, "com.android.settings", table, "PUT", key, bundle); return }
                    6 -> { m.invoke(provider, "com.android.settings", null, table, "PUT", key, bundle); return }
                }
            } catch (_: Exception) { continue }
        }
        throw RuntimeException("IContentProvider.call falhou para $table/$key")
    }
}
